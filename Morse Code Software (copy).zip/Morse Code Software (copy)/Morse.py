# -*- coding: utf-8 -*-
"""
Created on Mon Apr 30 18:29:42 2018

@author: shohanur
"""

import gi
import Morse_Code
from sound import Sound

gi.require_version('Gtk', '3.0')
from gi.repository import Gtk 

'''window = Gtk.Window()
window.connect("delete-event",Gtk.main_quit)
window.show_all()
Gtk.main()'''

class MainWindow(Gtk.Window,Morse_Code.morse,Sound):
    
    
    def __init__(self):
        Gtk.Window.__init__(self,title = "Morse-Code-Encoder-Decoder")
        Morse_Code.morse.__init__(self,'morse.txt')
        Sound.__init__(self,4000)
        self.set_border_width(10)
        self.set_size_request(400,200)
        
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=10)       
        hbox1 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=20)
        hbox2 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=20)
        hbox3 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=20)
        hbox4 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=20) 
        hbox5 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=20)
        hbox6 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=20)
        hbox7 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=20)
        
        
        label1 = Gtk.Label('Unencrypted Data:',xalign=0) 
        label2 = Gtk.Label('Encrypted Data:',xalign=0)
        label3 = Gtk.Label('© By Md.Shohanur Rahman,EEE,RUET',xalign=0)
        '''
        vbox1 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=25)
        vbox2 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=20)
        vbox3 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=20)
        vbox4 = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=20)
        
        listbox = Gtk.ListBox()
        listbox.set_selection_mode(Gtk.SelectionMode.NONE)'''
        
        self.entry_unencrypted = Gtk.Entry()
        self.entry_encrypted   = Gtk.Entry()
        #self.entry_unencrypted.set_text("Hello World")
        
        self.encode = Gtk.Button(label = 'Encode')
        self.decode = Gtk.Button(label = 'Decode')
        self.sound = Gtk.Button(label = 'Morse Sound')
        self.clear_box = Gtk.Button(label = 'Clear')
        self.decode_sound = Gtk.Button(label = 'Decode Audio')
        
        hbox1.pack_start(label1,True,True,0)
        hbox2.pack_start(self.entry_unencrypted,True,True,0)
        hbox2.pack_start(self.encode,True,True,0)
        hbox3.pack_start(label2,True,True,0)
        hbox4.pack_start(self.entry_encrypted,True,True,0)
        hbox4.pack_start(self.decode,True,True,0)
        hbox5.pack_start(self.sound,True,True,0)
        hbox5.pack_start(self.decode_sound,True,True,0)
        hbox6.pack_start(label3,True,True,0)
        hbox7.pack_start(self.clear_box,True,True,0)        
        
        vbox.pack_start(hbox1,True,True,0)
        vbox.pack_start(hbox2,True,True,0)
        vbox.pack_start(hbox3,True,True,0)
        vbox.pack_start(hbox4,True,True,0)
        vbox.pack_start(hbox5,True,True,0)
        vbox.pack_start(hbox7,True,True,0)
        vbox.pack_start(hbox6,True,True,0)        
        
        self.add(vbox)
    
        self.encode.connect("clicked", self.encode_clicked)
        self.decode.connect("clicked", self.decode_clicked)
        self.sound.connect("clicked",self.make_sound)
        self.clear_box.connect("clicked",self.clear_box_)

    def encode_clicked(self,encode):
        get_txt = self.entry_unencrypted.get_text()
        get_txt = self.encode_sentence(get_txt.upper())
        self.entry_encrypted.set_text(get_txt)

    
    def decode_clicked(self,decode):
        get_txt = self.entry_encrypted.get_text()
        get_txt = self.decode_sen(get_txt)
        self.entry_unencrypted.set_text(get_txt)
    
    
    def clear_box_(self,clear_box):
        self.entry_unencrypted.set_text('')
        self.entry_encrypted.set_text('')
    
    def make_sound(self,sound):
        get_txt = self.entry_unencrypted.get_text()
        get_txt = self.encode_sentence(get_txt.upper())
        print(get_txt)
        self.senSound(get_txt)
        print(get_txt)
    
if __name__=="__main__":
    window = MainWindow()
    window.connect("delete-event",Gtk.main_quit)
    window.show_all()
    Gtk.main()       
        
        
        
        
        
